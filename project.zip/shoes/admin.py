from django.contrib import admin
from .models import Shoe, Review

admin.site.register(Shoe)
admin.site.register(Review)
